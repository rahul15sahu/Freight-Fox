// Production Firestore Bootstrap 
// This file patches Firestore in production environments without affecting development

// Only run this code in production
if (import.meta.env.PROD) {
  try {
    console.log("[FreightFox] Initializing production Firestore patches");
    
    // Dynamically patch Firestore imports in production
    // This approach ensures we don't modify any development code
    const originalModule = await import('firebase/firestore');
    
    // Store the original getFirestore function
    const originalGetFirestore = originalModule.getFirestore;
    
    // Override getFirestore to use our production-optimized settings
    originalModule.getFirestore = function(app) {
      const { initializeFirestore } = originalModule;
      
      try {
        // Use optimized settings for production that specifically address the 400 Bad Request error
        return initializeFirestore(app, {
          // Force long polling which is more reliable in problematic network environments
          experimentalForceLongPolling: true,
          
          // Disable auto-detection to prevent switching to WebSocket, which can cause the 400 errors
          experimentalAutoDetectLongPolling: false,
          
          // Increase cache size for better offline capabilities
          cacheSizeBytes: 50 * 1024 * 1024, // 50MB
          
          // Add these settings to help with 400 Bad Request errors
          experimentalForceRestTransport: true,
          
          // Ignore undefined properties to prevent serialization errors
          ignoreUndefinedProperties: true,
          
          // Add more frequent heartbeats to keep the connection alive
          heartbeatInterval: 120000, // 2 minutes
          
          // Use more reliable settings for timeouts
          maxAttempts: 5,
          retryDelayMultiplier: 2.0
        });
      } catch (error) {
        console.warn("[FreightFox] Failed to initialize production Firestore with advanced options, trying simpler setup", error);
        
        try {
          // Try a simpler configuration that should still help with the 400 error
          return initializeFirestore(app, {
            experimentalForceLongPolling: true,
            ignoreUndefinedProperties: true
          });
        } catch (fallbackError) {
          console.error("[FreightFox] All optimizations failed, using default Firestore", fallbackError);
          // Fall back to original function if all optimizations fail
          return originalGetFirestore(app);
        }
      }
    };
    
    console.log("[FreightFox] Production Firestore patches applied");
  } catch (error) {
    console.error("[FreightFox] Failed to apply production Firestore patches", error);
  }
}
