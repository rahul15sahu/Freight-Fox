// Direct Firestore Fix Utility
// This provides tools for fixing Firestore connection issues in production
// Import for immediate use: import { fixFirestoreQuery } from '../shared/firestoreFix'

import { getFirestore, initializeFirestore } from 'firebase/firestore';
import { app } from './sharedConfig';

// Production-optimized Firestore instance
let prodDb = null;

// Only create the production DB in production environment
if (import.meta.env.PROD) {
  try {
    // Use more robust settings for production
    prodDb = initializeFirestore(app, {
      // Force long polling which is more reliable in problematic network environments
      experimentalForceLongPolling: true,
      
      // Disable auto-detection to prevent switching to WebSocket, which can cause the 400 errors
      experimentalAutoDetectLongPolling: false,
      
      // Increase cache size for better offline capabilities
      cacheSizeBytes: 50 * 1024 * 1024, // 50MB
      
      // Add these settings to help with 400 Bad Request errors
      experimentalForceRestTransport: true,
      
      // Ignore undefined properties to prevent serialization errors
      ignoreUndefinedProperties: true,
      
      // Add more frequent heartbeats to keep the connection alive
      heartbeatInterval: 120000, // 2 minutes
      
      // Use more reliable settings for timeouts
      maxAttempts: 5,
      retryDelayMultiplier: 2.0
    });
    console.log('[FreightFox] Production-optimized Firestore instance created with enhanced settings');
  } catch (e) {
    console.warn('[FreightFox] Could not create optimized Firestore instance', e);
    // Fallback to regular instance but with minimal optimizations
    try {
      prodDb = initializeFirestore(app, {
        experimentalForceLongPolling: true,
        ignoreUndefinedProperties: true
      });
      console.log('[FreightFox] Fallback production Firestore instance created');
    } catch (fallbackError) {
      console.error('[FreightFox] All optimizations failed, using default instance', fallbackError);
      prodDb = getFirestore(app);
    }
  }
} else {
  // In development, use the regular instance
  prodDb = getFirestore(app);
}

// Export the production-optimized DB
export const prodFirestore = prodDb;

/**
 * Fix a Firestore query by using the production-optimized instance
 * This can be used as a direct fix for queries that are failing
 * 
 * Example usage:
 * import { fixFirestoreQuery } from './firestoreFix';
 * 
 * // Instead of this:
 * const querySnapshot = await getDocs(collection(db, 'Users'));
 * 
 * // Do this:
 * const querySnapshot = await fixFirestoreQuery(
 *   (db) => getDocs(collection(db, 'Users'))
 * );
 */
export async function fixFirestoreQuery(queryFn) {
  try {
    // Use the production DB to execute the query
    return await queryFn(prodDb);
  } catch (error) {
    console.warn('[FreightFox] Error with optimized Firestore query, retrying...', error?.message || error);
    
    // Check if this is a known 400 error
    if (error?.message?.includes('FAILED_PRECONDITION') || 
        error?.message?.includes('Bad Request') || 
        error?.message?.includes('transport') || 
        error?.message?.includes('Listen') || 
        error?.message?.includes('WebChannelConnection')) {
      // Wait a bit longer for network issues (3 seconds)
      await new Promise(resolve => setTimeout(resolve, 3000));
      
      console.log('[FreightFox] Reconnecting to Firestore...');
      
      // We need to reinitialize the instance for 400 Bad Request errors
      try {
        // Reinitialize with updated settings
        prodDb = initializeFirestore(app, {
          experimentalForceLongPolling: true,
          experimentalAutoDetectLongPolling: false,
          cacheSizeBytes: 50 * 1024 * 1024,
          ignoreUndefinedProperties: true,
          heartbeatInterval: 120000 // 2 minutes heartbeat
        });
        
        console.log('[FreightFox] Firestore connection reestablished');
        
        // Try again with the refreshed instance
        return await queryFn(prodDb);
      } catch (reinitError) {
        console.error('[FreightFox] Failed to reinitialize Firestore', reinitError);
        throw reinitError;
      }
    } else {
      // For other errors, just retry once
      await new Promise(resolve => setTimeout(resolve, 2000));
      
      try {
        return await queryFn(prodDb);
      } catch (retryError) {
        console.error('[FreightFox] Firestore query failed after retry', retryError);
        throw retryError;
      }
    }
  }
}

/**
 * Simple utility to convert a regular Firestore reference to use the production DB
 * 
 * Example usage:
 * import { convertToProdRef } from './firestoreFix';
 * 
 * const regularRef = doc(db, 'Users', 'user123');
 * const fixedRef = convertToProdRef(regularRef);
 */
export function convertToProdRef(regularRef) {
  // Only needed in production
  if (!import.meta.env.PROD) {
    return regularRef;
  }
  
  try {
    const { doc } = require('firebase/firestore');
    
    // Extract path from regular reference
    const path = regularRef.path;
    if (!path) return regularRef;
    
    // Split path to get collection and document ID
    const parts = path.split('/');
    if (parts.length !== 2) return regularRef;
    
    // Create a new reference using the production DB
    return doc(prodDb, parts[0], parts[1]);
  } catch (e) {
    console.warn('[FreightFox] Could not convert Firestore reference', e);
    return regularRef;
  }
}
