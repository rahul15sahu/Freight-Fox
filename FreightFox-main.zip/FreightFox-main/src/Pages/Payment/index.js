import PaymentPage from './PaymentPage';
export default PaymentPage;
