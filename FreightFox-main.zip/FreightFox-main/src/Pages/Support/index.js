import SupportPage from './SupportPage';
export default SupportPage;
